import aiohttp
import argparse
import asyncio
import base64
import csv
import datetime
import grpc
import itertools
import json
import logging
import math
import os
import pydantic
import random
import tqdm

from google.protobuf.json_format import ParseDict
from statistics import quantiles
from typing import Literal
from yandex.cloud.searchapi.v2 import web_search_pb2
from yandex.cloud.searchapi.v2 import web_search_pb2_grpc


logging.basicConfig(level=logging.DEBUG)
lock = asyncio.Lock()


class TraceResult(pydantic.BaseModel):
    start_time: datetime.datetime
    end_time: datetime.datetime
    latency: int
    reqid: str | None
    context: dict | None
    rejected: bool
    text: str | None

    @classmethod
    def new(
        cls,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        reqid: str | None = None,
        context: dict | None = None,
        rejected: bool = False,
        text: str | None = None,
    ):
        latency = delta_ms(start_time, end_time)
        return cls(
            start_time=start_time,
            end_time=end_time,
            latency=latency,
            reqid=reqid,
            context=context,
            rejected=rejected,
            text=text
        )


class SetraceResult(TraceResult):
    pass


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--queries-file", type=str, default="queries.jsonl")
    parser.add_argument("--threads-count", type=int)
    parser.add_argument("--requests-count", type=int)
    parser.add_argument("--groups-on-page", type=int)
    parser.add_argument("--lang", type=str)
    parser.add_argument("--action", type=str)
    parser.add_argument("--full-texts", action=argparse.BooleanOptionalAction)
    parser.add_argument("--no-reuse-ssl", action=argparse.BooleanOptionalAction)
    parser.add_argument("--output", type=str)
    return parser.parse_args()


def delta_ms(start: datetime.datetime, end: datetime.datetime):
    convert_dt = lambda x: (
        datetime.datetime.fromisoformat(x) if isinstance(x, str) else x
    )
    return int((convert_dt(end) - convert_dt(start)).total_seconds() * 1_000)


def get_base_url(action: str):
    return {
        "v1": "https://yandex.com",
        "v2": "https://searchapi.api.cloud.yandex.net",
        "v2_images": "https://searchapi.api.cloud.yandex.net",
        "ping": "https://yandex.com",
        "grpc_default": "https://searchapi.api.cloud.yandex.net",
        "grpc_dedicated": "https://api.search.yandexcloud.net",
    }.get(action)


def get_trace_config():
    async def on_event(session, trace_config_ctx, params):
        kind = params.__class__.__name__.split(".")[-1].lstrip("Trace").rstrip("Params")
        trace_config_ctx.trace_request_ctx[kind] = datetime.datetime.now()

    config = aiohttp.TraceConfig()
    events = [
        "on_request_start",
        "on_connection_queued_start",
        "on_connection_create_start",
        "on_connection_reuseconn",
        "on_connection_queued_end",
        "on_connection_create_end",
        "on_request_headers_sent",
        "on_request_end",
        "on_request_chunk_sent",
        "on_response_chunk_received",
    ]
    for event in events:
        getattr(config, event).append(on_event)
    return config


async def do_nothing():
    return


async def trace_single(
    session: aiohttp.ClientSession,
    pbar: tqdm.tqdm,
    action: Literal["v1", "v2", "v2_images", "ping", "grpc_default", "grpc_dedicated"],
    full_texts: bool,
    no_reuse_ssl: bool,
    queries,
    groups_on_page: int,
    lang: str | None,
    requests_count: int,
    results: list,
    results_count: list,
):
    async def inner(session: aiohttp.ClientSession):
        if action == "v1":
            response = await session.get(
                "/search/xml",
                headers={"Authorization": "Api-Key " + os.environ["SEARCH_API_KEY"]},
                params={
                    "text": query,
                    "folderid": os.environ["SEARCH_API_FOLDERID"],
                    "groupby": f"attr=d.mode=deep.groups-on-page={groups_on_page}",
                } | ({"xml_full_texts": "1"} if full_texts else {}),
                trace_request_ctx=context,
            )
            text = await response.text()
            end_time = datetime.datetime.now()
            reqid = response.headers.get("X-Yandex-Req-Id")
        elif action == "v2":
            response = await session.post(
                "/v2/web/search",
                headers={"Authorization": "Bearer  " + os.environ["SEARCH_API_KEY"]},
                json={
                    "query": {"queryText": query, "searchType": "SEARCH_TYPE_COM"},
                    "folderid": os.environ["SEARCH_API_FOLDERID"],
                    "responseFormat": "FORMAT_XML",
                    "groupSpec": {
                        "groupMode": "GROUP_MODE_DEEP",
                        "groupsOnPage": str(groups_on_page),
                    }
                },
                trace_request_ctx=context,
            )
            text = await response.text()
            end_time = datetime.datetime.now()
            try:
                text = base64.b64decode((await response.json())["rawData"]).decode()
                reqid = text.split("<reqid>")[1].split("</reqid>")[0]
            except:
                reqid = None
        elif action == "ping":
            response = await session.get(
                "/ping",
                trace_request_ctx=context,
            )
            text = await response.text()
            end_time = datetime.datetime.now()
            reqid = None
        elif action in ("grpc_default", "grpc_dedicated"):
            stub = web_search_pb2_grpc.WebSearchServiceStub(channel)
            request_dict = {
                "query": {
                    "search_type": "SEARCH_TYPE_COM",
                    "query_text": query,
                },
                "folder_id": os.environ["SEARCH_API_FOLDERID"],
                "response_format": "FORMAT_XML",
                "group_spec": {
                    "groupMode": "GROUP_MODE_DEEP",
                    "groupsOnPage": str(groups_on_page),
                }
            }
            
            request = web_search_pb2.WebSearchRequest() # type: ignore
            ParseDict(request_dict, request)
            context["RequestStart"] = datetime.datetime.now()
            response = await stub.Search(request, metadata=(("x-xml-full-text", "1"),) if full_texts else None)
            end_time = datetime.datetime.now()
            text = response.raw_data.decode()
            try:
                reqid = text.split("<reqid>")[1].split("</reqid>")[0]
            except:
                reqid = None
        return text, end_time, reqid

    global lock
    while True:
        async with lock:
            if results_count[0] >= requests_count:
                break
            results_count[0] += 1
            pbar.update(results_count[0] - pbar.n)
        context = {}
        query = " ".join(next(queries)) + (" lang:" + lang if lang else "")
        if no_reuse_ssl:
            base_url = get_base_url(action)
            async with aiohttp.ClientSession(
                base_url, trace_configs=[get_trace_config()]
            ) as session:
                text, end_time, reqid = await inner(session)
        else:
            text, end_time, reqid = await inner(session)
        results.append(
            TraceResult.new(
                start_time=context["RequestStart"],
                end_time=end_time,
                reqid=reqid,
                context=context,
                rejected=("<results>" not in text) and ("rawData" not in text),
                text=text,
            )
        )


def create_grpc_channel(action: str):
    """Create an authenticated gRPC channel."""
    credentials = grpc.access_token_call_credentials(os.environ["SEARCH_API_KEY"])
    channel_credentials = grpc.composite_channel_credentials(
        grpc.ssl_channel_credentials(),
        credentials
    )
    MAX_MESSAGE_LENGTH = 10_000_000
    return grpc.aio.secure_channel(
        get_base_url(action).replace("https://", "") + ":443",
        channel_credentials,
        options=[
            ('grpc.max_message_length', MAX_MESSAGE_LENGTH),
            ('grpc.max_send_message_length', MAX_MESSAGE_LENGTH),
            ('grpc.max_receive_message_length', MAX_MESSAGE_LENGTH),
        ],
    )


async def main(
    threads_count: int,
    requests_count: int,
    queries_file: str,
    groups_on_page: int,
    lang: str | None,
    action: str,
    full_texts: bool,
    no_reuse_ssl: bool,
    output: str,
):
    base_url = get_base_url(action)
    if os.path.exists(queries_file):
        unique_queries = [
            [json.loads(line)["query"]] for line in open(queries_file)
        ]
    else:
        logging.info("No queries file found, generating queries...")
        unique_queries = list(
            itertools.product(
                ["tiny", "small", "medium", "big", "huge"],
                ["red", "green", "blue", "violet", "black"],
                ["rose", "onion", "fly", "elephant", "owl", "tree"],
            )
        )
    queries = itertools.chain.from_iterable(
        itertools.repeat(
            unique_queries, math.ceil(requests_count / len(unique_queries))
        )
    )
    pbar = tqdm.tqdm(total=requests_count + threads_count)
    if action in ("grpc_default", "grpc_dedicated"):
        global channel
        channel = create_grpc_channel(action)
    async with aiohttp.ClientSession(
        base_url, trace_configs=[get_trace_config()]
    ) as session:
        traces, traces_count = [], [0]
        await asyncio.gather(
            *[
                trace_single(
                    session,
                    pbar,
                    action,
                    full_texts,
                    no_reuse_ssl,
                    queries,
                    groups_on_page,
                    lang,
                    requests_count + threads_count,
                    traces,
                    traces_count,
                )
                for _ in range(threads_count)
            ]
        )
        traces = traces[threads_count:]
    data = [[
        "Reqid",
        "Rejected",
        "Local Start",
        "Local End",
        "Local Latency",
        "Local Trace",
        "Min Latency",
        "Median Latency",
        "P95",
        "P99",
        "Max Latency",
    ]]
    for row_id, trace_result in enumerate(traces):
        timings = sorted(
            (trace_result.context or {}).items(),
            key=lambda x: x[1],
        )
        full_trace, start_time = "", None
        for key, value in timings:
            if not start_time:
                start_time = value
            full_trace += f"{key}: {delta_ms(start_time, value)}\n"
        data.append(
            [
                trace_result.reqid,
                ["false", "true"][trace_result.rejected],
                trace_result.start_time.isoformat(),
                trace_result.end_time.isoformat(),
                trace_result.latency,
                full_trace,
            ]
        )
        data[-1].extend([
            "=MIN(E:E)",
            "=MEDIAN(E:E)",
            "=PERCENTILE.INC(E:E;0,95)",
            "=PERCENTILE.INC(E:E;0,99)",
            "=MAX(E:E)",
        ] if row_id == 0 else [""] * 3)
        
    with open(output, "w") as csvfile:
        writer = csv.writer(csvfile, delimiter=";")
        writer.writerows(data)
    latencies = [trace.latency for trace in traces]
    print(quantiles(latencies, n=100)[94])
    print(quantiles(latencies, n=100)[98])


if __name__ == "__main__":
    args = get_args()
    asyncio.run(
        main(
            threads_count=args.threads_count,
            requests_count=args.requests_count,
            queries_file=args.queries_file,
            groups_on_page=args.groups_on_page,
            lang=args.lang,
            action=args.action,
            full_texts=args.full_texts,
            no_reuse_ssl=args.no_reuse_ssl,
            output=args.output,
        )
    )
