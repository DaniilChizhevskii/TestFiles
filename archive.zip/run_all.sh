#!/bin/bash

if [ ! -d venv ]; then
    python3 -m venv venv
fi

source venv/bin/activate
pip3 install -r requirements.txt >> /dev/null

python3 main.py --threads-count $THREADS_COUNT --requests-count $REQUESTS_COUNT --action v2 --groups-on-page 50 --lang en --output report_rest_top_50_lang_en.csv
python3 main.py --threads-count $THREADS_COUNT --requests-count $REQUESTS_COUNT --action grpc_default --groups-on-page 50 --lang en --output report_grpc_default_top_50_lang_en.csv